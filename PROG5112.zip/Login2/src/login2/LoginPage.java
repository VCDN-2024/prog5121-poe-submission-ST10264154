package login2;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginPage implements ActionListener {

    JFrame frame = new JFrame();
    JButton loginB = new JButton("Login");
    JButton loginS = new JButton("Sign up");
    JTextField userIDField = new JTextField();
    JPasswordField userPasswordField = new JPasswordField();
    JLabel userIDLabel = new JLabel("Username: ");
    JLabel userPasswordLabel = new JLabel("Password: ");
    JLabel messageLabel = new JLabel();

    LoginPage() {
        userIDLabel.setBounds(50, 100, 75, 25);
        userPasswordLabel.setBounds(50, 150, 75, 25);

        userIDField.setBounds(125, 100, 200, 25);
        userPasswordField.setBounds(125, 150, 200, 25);

        loginB.setBounds(125, 200, 100, 25);
        loginB.setFocusable(false);
        loginB.addActionListener(this);
        loginB.setBackground(new Color(203, 195, 227));
        
        loginS.setBounds(225, 200, 100, 25);
        loginS.setFocusable(false);
        loginS.addActionListener(this);
        loginS.setBackground(Color.PINK);

        messageLabel.setBounds(40, 250, 300, 35);
        messageLabel.setFont(new Font(null, Font.ITALIC, 12));

        frame.add(userIDLabel);
        frame.add(userPasswordLabel);
        frame.add(userIDField);
        frame.add(userPasswordField);
        frame.add(loginB);
        frame.add(loginS);
        frame.add(messageLabel);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420, 420);
        frame.setLayout(null);
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String userID = userIDField.getText();
        String password = String.valueOf(userPasswordField.getPassword());

        if (e.getSource() == loginB) {
            if (userID.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Username and password cannot be empty", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (authenticate(userID, password)) {
                messageLabel.setText("Login successful!");
                frame.dispose();
                new UserWelcome(userID);
                new NewWelcome();
            } else {
                JOptionPane.showMessageDialog(frame, "Username or password incorrect, please try again", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getSource() == loginS) {
            if (userID.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Username and password cannot be empty", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                if (register(userID, password)) {
                    JOptionPane.showMessageDialog(frame, "Registration successful!", "Information", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, "Registration failed, please try again", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private boolean authenticate(String username, String password) {
        try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts[0].equals(username) && parts[1].equals(password)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean register(String username, String password) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt", true))) {
            writer.write(username + ":" + password);
            writer.newLine();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void main(String[] args) {
        new LoginPage();
    }
}


