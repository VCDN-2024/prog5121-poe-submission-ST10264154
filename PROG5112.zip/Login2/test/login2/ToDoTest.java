package login2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ToDoTest {

    private ToDo todoApp;

    public ToDoTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
        todoApp = new ToDo();
        todoApp.tasks = new ArrayList<>(); // Reset tasks
        todoApp.tasks.add(new Task("To Do", "Mike Smith", "0", "Create Login", "Login functionality", "CR:0:ITH", 5));
        todoApp.tasks.add(new Task("Doing", "Edward Harrison", "1", "Create Add Features", "Add features functionality", "CR:1:SON", 8));
        todoApp.tasks.add(new Task("Done", "Samantha Paulson", "2", "Create Reports", "Reports functionality", "CR:2:SON", 2));
        todoApp.tasks.add(new Task("To Do", "Glenda Oberholzer", "3", "Add Arrays", "Add arrays functionality", "CR:3:ZER", 11));
    }

    @After
    public void tearDown() {
    }

    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        ToDo.main(args);
        fail("The test case is a prototype.");
    }

    // Test for Task Description length
    @Test
    public void testTaskDescriptionLength() {
        String shortDescription = "Create Login to authenticate users";
        String longDescription = "This is a task description with more than 50 characters which should fail.";
        assertTrue("Task successfully captured", shortDescription.length() <= 50);
        assertFalse("Please enter a task description of less than 50 characters", longDescription.length() <= 50);
    }

    // Test for TaskID format
    @Test
    public void testTaskIDFormat() {
        String taskId1 = "AD:1:BYN";
        String taskId2 = "CR:0:IKE";
        assertTrue(taskId1.matches("^[A-Z]{2}:[0-9]+:[A-Z]{3}$"));
        assertTrue(taskId2.matches("^[A-Z]{2}:[0-9]+:[A-Z]{3}$"));
    }

    // Test for Total Hours Accumulation
    @Test
    public void testTotalHoursAccumulation() {
        int[] durations1 = {8, 10};
        int totalHours1 = 0;
        for (int duration : durations1) {
            totalHours1 += duration;
        }
        assertEquals(18, totalHours1);

        int[] durations2 = {10, 12, 55, 11, 1};
        int totalHours2 = 0;
        for (int duration : durations2) {
            totalHours2 += duration;
        }
        assertEquals(89, totalHours2);
    }

    // Developer Array Correctly Populated
    @Test
    public void testDeveloperArrayPopulated() {
        String[] expectedDevelopers = {"Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberholzer"};
        assertArrayEquals(expectedDevelopers, todoApp.developers);
    }

    // Display Developer and Duration for Task with Longest Duration
    @Test
    public void testLongestDurationTask() {
        Task expectedLongestTask = new Task("To Do", "Glenda Oberholzer", "3", "Add Arrays", "Add arrays functionality", "CR:3:ZER", 11);
        Task longestTask = todoApp.tasks.stream().max(Comparator.comparingDouble(Task::getDuration)).orElse(null);
        assertNotNull(longestTask);
        assertEquals(expectedLongestTask.getDeveloper(), longestTask.getDeveloper());
        assertEquals(expectedLongestTask.getDuration(), longestTask.getDuration(), 0);
    }

    // Search for Tasks by Task Name
    @Test
    public void testSearchTaskByName() {
        String taskName = "Create Login";
        Task task = todoApp.tasks.stream().filter(t -> t.getName().equalsIgnoreCase(taskName)).findFirst().orElse(null);
        assertNotNull(task);
        assertEquals("Mike Smith", task.getDeveloper());
        assertEquals("Create Login", task.getName());
    }

    // Search for Tasks by Developer
    @Test
    public void testSearchTasksByDeveloper() {
        String developer = "Samantha Paulson";
        List<Task> developerTasks = todoApp.tasks.stream().filter(t -> t.getDeveloper().equalsIgnoreCase(developer)).collect(Collectors.toList());
        assertNotNull(developerTasks);
        assertEquals(1, developerTasks.size());
        assertEquals("Create Reports", developerTasks.get(0).getName());
    }

    // Delete Task from Array
    @Test
    public void testDeleteTask() {
        String taskName = "Create Reports";
        Task task = todoApp.tasks.stream().filter(t -> t.getName().equalsIgnoreCase(taskName)).findFirst().orElse(null);
        assertNotNull(task);
        todoApp.tasks.remove(task);
        assertNull(todoApp.tasks.stream().filter(t -> t.getName().equalsIgnoreCase(taskName)).findFirst().orElse(null));
    }

    // Display All Tasks Report
    @Test
    public void testDisplayAllTasksReport() {
        StringBuilder expectedReport = new StringBuilder("All Tasks:\n");
        expectedReport.append("Status: To Do, Developer: Mike Smith, Number: 0, Name: Create Login, Description: Login functionality, ID: CR:0:ITH, Duration: 5.0 hours\n");
        expectedReport.append("Status: Doing, Developer: Edward Harrison, Number: 1, Name: Create Add Features, Description: Add features functionality, ID: CR:1:SON, Duration: 8.0 hours\n");
        expectedReport.append("Status: Done, Developer: Samantha Paulson, Number: 2, Name: Create Reports, Description: Reports functionality, ID: CR:2:SON, Duration: 2.0 hours\n");
        expectedReport.append("Status: To Do, Developer: Glenda Oberholzer, Number: 3, Name: Add Arrays, Description: Add arrays functionality, ID: CR:3:ZER, Duration: 11.0 hours\n");

        StringBuilder actualReport = new StringBuilder("All Tasks:\n");
        for (Task task : todoApp.tasks) {
            actualReport.append(String.format("Status: %s, Developer: %s, Number: %s, Name: %s, Description: %s, ID: %s, Duration: %.2f hours\n",
                    task.getStatus(), task.getDeveloper(), task.getNumber(), task.getName(), task.getDescription(), task.getID(), task.getDuration()));
        }

        assertEquals(expectedReport.toString(), actualReport.toString());
    }
}


