package login2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

class ToDo {

    JFrame frame = new JFrame("To-Do List");
    DefaultListModel<String> listModel = new DefaultListModel<>();
    JList<String> list = new JList<>(listModel);
    JTextField taskNameField = new JTextField(20);
    JTextField taskDescriptionField = new JTextField(20);
    JTextField taskDurationField = new JTextField(20);
    String[] statusOptions = {"To Do", "Done", "Doing"};
    JComboBox<String> taskStatusComboBox = new JComboBox<>(statusOptions);
    String[] developers = {"Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberholzer"}; //new combo box with developer names
    JComboBox<String> developerComboBox = new JComboBox<>(developers);

    JLabel totalHoursLabel = new JLabel("Total Hours: 0");
    double totalHours = 0;

    JButton addTaskButton = new JButton("Add Task");
    JButton displayDoneTasksButton = new JButton("Display Done Tasks");
    JButton displayLongestTaskButton = new JButton("Display Longest Task");
    JButton searchTaskButton = new JButton("Search Task");
    JButton searchDeveloperTasksButton = new JButton("Search Developer Tasks");
    JButton deleteTaskButton = new JButton("Delete Task");
    JButton displayAllTasksButton = new JButton("Display All Tasks");

    List<Task> tasks = new ArrayList<>();
    static int taskCounter = 0;

    public ToDo() {
        populateTestData();

        JPanel inputPanel = new JPanel(new GridLayout(8, 2));

        inputPanel.add(new JLabel("Task Status:"));
        inputPanel.add(taskStatusComboBox);

        inputPanel.add(new JLabel("Developer Details:"));
        inputPanel.add(developerComboBox);

        inputPanel.add(new JLabel("Task Number:"));
        JLabel taskNumberLabel = new JLabel();
        inputPanel.add(taskNumberLabel);

        inputPanel.add(new JLabel("Task Name:"));
        inputPanel.add(taskNameField);

        inputPanel.add(new JLabel("Task Description:"));
        inputPanel.add(taskDescriptionField);

        inputPanel.add(new JLabel("Task ID:"));
        JLabel taskIDLabel = new JLabel();
        inputPanel.add(taskIDLabel);

        inputPanel.add(new JLabel("Task Duration(Hours):"));
        inputPanel.add(taskDurationField);

        addTaskButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String taskName = taskNameField.getText();
                String taskDescription = taskDescriptionField.getText();
                String developerDetails = (String) developerComboBox.getSelectedItem();
                String taskDurationText = taskDurationField.getText();
                String taskStatus = (String) taskStatusComboBox.getSelectedItem();

                if (!taskName.isEmpty() && !taskDescription.isEmpty() &&
                        !developerDetails.isEmpty() && !taskDurationText.isEmpty() &&
                        taskStatus != null && developerDetails.length() >= 3 && taskName.length() >= 2) {

                    if (taskDescription.length() > 50) {
                        JOptionPane.showMessageDialog(frame, "Please enter a task description of less than 50 characters", "Description Too Long", JOptionPane.WARNING_MESSAGE);
                        return;
                    }

                    try {
                        double taskDuration = Double.parseDouble(taskDurationText);
                        totalHours += taskDuration;
                        totalHoursLabel.setText("Total Hours: " + totalHours);

                        String taskNumber = String.valueOf(taskCounter);
                        String taskID = (taskName.substring(0, 2) + ":" + taskNumber + ":" + developerDetails.substring(developerDetails.length() - 3)).toUpperCase();
                        String taskDetails = String.format("Status: %s, Developer: %s, Number: %s, Name: %s, Description: %s, ID: %s, Duration: %.2f hours",
                                taskStatus, developerDetails, taskNumber, taskName, taskDescription, taskID, taskDuration);
                        listModel.addElement(taskDetails);

                        tasks.add(new Task(taskStatus, developerDetails, taskNumber, taskName, taskDescription, taskID, taskDuration));

                        taskCounter++;

                        taskNameField.setText("");
                        taskDescriptionField.setText("");
                        developerComboBox.setSelectedIndex(0);
                        taskDurationField.setText("");
                        taskStatusComboBox.setSelectedIndex(0);

                        taskNumberLabel.setText(taskNumber);
                        taskIDLabel.setText(taskID);

                        JOptionPane.showMessageDialog(frame, "Task successfully captured", "Success", JOptionPane.INFORMATION_MESSAGE);

                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(frame, "Please enter a valid number for Task Duration E.g. 12, 15, 2.", "Invalid Input", JOptionPane.WARNING_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Please fill in all fields correctly.", "Incomplete Data", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        inputPanel.add(new JLabel(""));
        inputPanel.add(addTaskButton);

        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(new JScrollPane(list), BorderLayout.CENTER);
        frame.add(totalHoursLabel, BorderLayout.SOUTH);

        JPanel buttonPanel = new JPanel(new GridLayout(2, 3));
        buttonPanel.add(displayDoneTasksButton);
        buttonPanel.add(displayLongestTaskButton);
        buttonPanel.add(searchTaskButton);
        buttonPanel.add(searchDeveloperTasksButton);
        buttonPanel.add(deleteTaskButton);
        buttonPanel.add(displayAllTasksButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);

        displayDoneTasksButton.addActionListener(e -> displayDoneTasks());
        displayLongestTaskButton.addActionListener(e -> displayLongestTask());
        searchTaskButton.addActionListener(e -> searchTask());
        searchDeveloperTasksButton.addActionListener(e -> searchDeveloperTasks());
        deleteTaskButton.addActionListener(e -> deleteTask());
        displayAllTasksButton.addActionListener(e -> displayAllTasks());

        frame.setSize(600, 600);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);

        addTaskButton.setBackground(new Color(203, 195, 227));
        displayDoneTasksButton.setBackground(Color.PINK);
        displayLongestTaskButton.setBackground(new Color(253,253,150));
        searchTaskButton.setBackground(Color.PINK);
        searchDeveloperTasksButton.setBackground(new Color(253,253,150));
        deleteTaskButton.setBackground(Color.PINK);
        displayAllTasksButton.setBackground(new Color(253,253,150));
    }

    private void populateTestData() {
        addTestData("To Do", "Mike Smith", "0", "Create Login", "Login functionality", "CR:0:ITH", 5);
        addTestData("Doing", "Edward Harrison", "1", "Create Add Features", "Add features functionality", "CR:1:SON", 8);
        addTestData("Done", "Samantha Paulson", "2", "Create Reports", "Reports functionality", "CR:2:SON", 2);
        addTestData("To Do", "Glenda Oberholzer", "3", "Add Arrays", "Add arrays functionality", "CR:3:ZER", 11);
    }

    private void addTestData(String status, String developer, String number, String name, String description, String ID, double duration) {
        Task task = new Task(status, developer, number, name, description, ID, duration);
        tasks.add(task);
        totalHours += duration;
        totalHoursLabel.setText("Total Hours: " + totalHours);

        String taskDetails = String.format("Status: %s, Developer: %s, Number: %s, Name: %s, Description: %s, ID: %s, Duration: %.2f hours",
                status, developer, number, name, description, ID, duration);
        listModel.addElement(taskDetails);

        taskCounter++;
    }

    private void displayDoneTasks() {
        StringBuilder report = new StringBuilder("Done Tasks:\n");
        for (Task task : tasks) {
            if ("Done".equalsIgnoreCase(task.getStatus())) {
                report.append(String.format("Developer: %s, Task Name: %s, Task Duration: %.2f hours\n", task.getDeveloper(), task.getName(), task.getDuration()));
            }
        }
        JOptionPane.showMessageDialog(frame, report.toString(), "Done Tasks", JOptionPane.INFORMATION_MESSAGE);
    }

    private void displayLongestTask() {
        Task longestTask = tasks.stream().max(Comparator.comparingDouble(Task::getDuration)).orElse(null);
        if (longestTask != null) {
            String message = String.format("Developer: %s, Task Duration: %.2f hours", longestTask.getDeveloper(), longestTask.getDuration());
            JOptionPane.showMessageDialog(frame, message, "Longest Task", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(frame, "No tasks found.", "Longest Task", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void searchTask() {
        String taskName = JOptionPane.showInputDialog(frame, "Enter Task Name:");
        if (taskName != null) {
            Task task = tasks.stream().filter(t -> t.getName().equalsIgnoreCase(taskName)).findFirst().orElse(null);
            if (task != null) {
                String message = String.format("Task Name: %s, Developer: %s, Task Status: %s", task.getName(), task.getDeveloper(), task.getStatus());
                JOptionPane.showMessageDialog(frame, message, "Search Task", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame, "Task not found.", "Search Task", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void searchDeveloperTasks() {
        String developer = JOptionPane.showInputDialog(frame, "Enter Developer Name:");
        if (developer != null) {
            StringBuilder report = new StringBuilder("Tasks for Developer " + developer + ":\n");
            for (Task task : tasks) {
                if (task.getDeveloper().equalsIgnoreCase(developer)) {
                    report.append(String.format("Task Name: %s, Task Status: %s\n", task.getName(), task.getStatus()));
                }
            }
            JOptionPane.showMessageDialog(frame, report.toString(), "Search Developer Tasks", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void deleteTask() {
        String taskName = JOptionPane.showInputDialog(frame, "Enter Task Name to Delete:");
        if (taskName != null) {
            Task task = tasks.stream().filter(t -> t.getName().equalsIgnoreCase(taskName)).findFirst().orElse(null);
            if (task != null) {
                tasks.remove(task);
                totalHours -= task.getDuration();
                totalHoursLabel.setText("Total Hours: " + totalHours);

                for (int i = 0; i < listModel.size(); i++) {
                    if (listModel.get(i).contains(task.getID())) {
                        listModel.remove(i);
                        break;
                    }
                }
                JOptionPane.showMessageDialog(frame, "Task successfully deleted", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame, "Task not found.", "Delete Task", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void displayAllTasks() {
        StringBuilder report = new StringBuilder("All Tasks:\n");
        for (Task task : tasks) {
            report.append(String.format("Status: %s, Developer: %s, Number: %s, Name: %s, Description: %s, ID: %s, Duration: %.2f hours\n",
                    task.getStatus(), task.getDeveloper(), task.getNumber(), task.getName(), task.getDescription(), task.getID(), task.getDuration()));
        }
        JOptionPane.showMessageDialog(frame, report.toString(), "All Tasks", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        new ToDo();
    }
}

class Task {
    private String status;
    private String developer;
    private String number;
    private String name;
    private String description;
    private String ID;
    private double duration;

    public Task(String status, String developer, String number, String name, String description, String ID, double duration) {
        this.status = status;
        this.developer = developer;
        this.number = number;
        this.name = name;
        this.description = description;
        this.ID = ID;
        this.duration = duration;
    }

    public String getStatus() {
        return status;
    }

    public String getDeveloper() {
        return developer;
    }

    public String getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getID() {
        return ID;
    }

    public double getDuration() {
        return duration;
    }
}






